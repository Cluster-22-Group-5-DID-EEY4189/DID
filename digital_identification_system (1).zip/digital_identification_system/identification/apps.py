from django.apps import AppConfig


class IdentificationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'identification'
